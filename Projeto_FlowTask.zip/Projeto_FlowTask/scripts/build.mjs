// Monta a pasta dist/ que vai para o Cloudflare Pages.
//   1. copia public/ → dist/
//   2. copia a biblioteca do Supabase (node_modules) → dist/vendor/supabase.js  (sem CDN de terceiros)
//   3. gera dist/config.js com SUPABASE_URL e SUPABASE_ANON_KEY vindas das variáveis de ambiente
//   4. gera dist/_headers (CSP e demais cabeçalhos) já com o endereço do seu projeto Supabase
//
// Variáveis lidas: SUPABASE_URL, SUPABASE_ANON_KEY (ou, para localhost, um arquivo .env na raiz).
// A chave service_role NUNCA deve ser definida aqui — o build recusa-se a continuar se detectá-la.
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const dist = path.join(root, 'dist');
const fail = (msg) => { console.error(`\n✖ ${msg}\n`); process.exit(1); };

// ---- .env local (opcional; no Cloudflare as variáveis já vêm do painel)
const envFile = path.join(root, '.env');
if (fs.existsSync(envFile)) {
  for (const line of fs.readFileSync(envFile, 'utf8').split(/\r?\n/)) {
    const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/.exec(line);
    if (m && !line.trim().startsWith('#') && process.env[m[1]] === undefined) {
      process.env[m[1]] = m[2].replace(/^['"]|['"]$/g, '');
    }
  }
}

const url = (process.env.SUPABASE_URL || '').trim().replace(/\/+$/, '');
const anon = (process.env.SUPABASE_ANON_KEY || '').trim();

// ---- validações
if (!url || !anon) fail('Defina SUPABASE_URL e SUPABASE_ANON_KEY (veja .env.example e o README).');
let origin;
try { origin = new URL(url); } catch { fail('SUPABASE_URL não é um endereço válido (ex.: https://abcdefgh.supabase.co).'); }
const isLocal = ['localhost', '127.0.0.1'].includes(origin.hostname);
if (origin.protocol !== 'https:' && !isLocal) fail('SUPABASE_URL precisa usar https://.');

function jwtRole(token) {
  try { return JSON.parse(Buffer.from(token.split('.')[1], 'base64url').toString('utf8')).role; } catch { return null; }
}
if (Object.keys(process.env).some((k) => /SERVICE_ROLE/i.test(k)) && !process.env.ALLOW_SERVICE_ROLE_VAR_FOR_TESTS) {
  fail('Foi detectada uma variável SERVICE_ROLE no ambiente do build. Ela NÃO deve existir aqui: remova-a (a chave de serviço só vive na Edge Function).');
}
if (jwtRole(anon) === 'service_role' || /^sb_secret_/.test(anon)) {
  fail('SUPABASE_ANON_KEY contém uma chave secreta (service_role). Use a chave PÚBLICA "anon"/"publishable".');
}

// ---- dist/
fs.rmSync(dist, { recursive: true, force: true });
fs.mkdirSync(path.join(dist, 'vendor'), { recursive: true });
for (const f of fs.readdirSync(path.join(root, 'public'))) {
  if (f === '_headers') continue; // é gerado abaixo
  fs.cpSync(path.join(root, 'public', f), path.join(dist, f), { recursive: true });
}

// ---- biblioteca do Supabase servida pelo próprio site
const require = createRequire(path.join(root, 'package.json'));
let lib;
try { lib = require.resolve('@supabase/supabase-js/dist/umd/supabase.js'); }
catch { fail('Biblioteca @supabase/supabase-js não encontrada. Rode "npm install" antes do build.'); }
fs.copyFileSync(lib, path.join(dist, 'vendor', 'supabase.js'));

// ---- config.js (somente valores PÚBLICOS)
const hasLogo = fs.existsSync(path.join(root, 'public', 'logo.png'));
fs.writeFileSync(path.join(dist, 'config.js'),
  `window.FLOWTASK_CONFIG = ${JSON.stringify({ SUPABASE_URL: url, SUPABASE_ANON_KEY: anon, HAS_LOGO: hasLogo })};\n`);

// ---- cabeçalhos de segurança (Cloudflare Pages lê o arquivo _headers)
const wss = `wss://${origin.host}`;
const connect = ["'self'", origin.origin, wss, ...(isLocal ? [`ws://${origin.host}`] : [])].join(' ');
const csp = [
  "default-src 'self'",
  "script-src 'self'",
  "style-src 'self'",
  "img-src 'self' data:",
  `connect-src ${connect}`,
  "font-src 'self'",
  "object-src 'none'",
  "base-uri 'none'",
  "form-action 'self'",
  "frame-ancestors 'none'",
].join('; ');
fs.writeFileSync(path.join(dist, '_headers'), `/*
  Content-Security-Policy: ${csp}
  X-Content-Type-Options: nosniff
  X-Frame-Options: DENY
  Referrer-Policy: no-referrer
  Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=()
  Strict-Transport-Security: max-age=31536000; includeSubDomains
  X-Robots-Tag: noindex, nofollow
  Cache-Control: no-cache

/vendor/*
  Cache-Control: public, max-age=86400
`);

console.log(`✔ dist/ pronto — Supabase: ${origin.origin} · logo: ${hasLogo ? 'sim' : 'não (usa o nome em texto)'}`);
