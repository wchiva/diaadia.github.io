// Gera public/styles.css a partir de src/styles.src.css (Tailwind v4, via API JS).
// Só é necessário rodar quando mudar classes/estilos:  npm run build:css
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const require = createRequire(path.join(root, 'package.json'));
const twDir = path.dirname(require.resolve('tailwindcss/package.json'));
const { compile } = await import(pathToFileURL(path.join(twDir, 'dist', 'lib.mjs')).href);

const loadStylesheet = async (id, base) => {
  const file = id === 'tailwindcss' ? path.join(twDir, 'index.css')
    : id.startsWith('tailwindcss/') ? path.join(twDir, id.slice('tailwindcss/'.length) + (id.endsWith('.css') ? '' : '.css'))
    : path.resolve(base, id);
  return { path: file, base: path.dirname(file), content: fs.readFileSync(file, 'utf8') };
};

const src = fs.readFileSync(path.join(root, 'src/styles.src.css'), 'utf8');
const compiler = await compile(src, { base: root, loadStylesheet });

// candidatos = qualquer "palavra" dos arquivos da interface (o Tailwind descarta o que não é classe)
const candidates = new Set();
for (const f of ['public/index.html', 'public/app.js']) {
  for (const m of fs.readFileSync(path.join(root, f), 'utf8').matchAll(/[^\s"'`<>=(){}\\,;]+/g)) candidates.add(m[0]);
}
const css = compiler.build([...candidates]);
fs.writeFileSync(path.join(root, 'public/styles.css'), css);
console.log(`public/styles.css gerado (${(css.length / 1024).toFixed(1)} KB)`);
